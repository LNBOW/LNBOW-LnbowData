<template>
  <div class="error">
    <p>404</p>
    <p>404</p>
    <p>404</p>
    <p>404</p>
    <p>404</p>
    <p>404</p>
    <p>404</p>
    <p>404</p>
    <p>404</p>
  </div>
</template>
