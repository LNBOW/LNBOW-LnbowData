export default {
  bLoading: false,
  index: [],
  user: {
    auth: false
  }
}