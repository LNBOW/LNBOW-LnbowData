export default {
  bLoading:(state)=>{return state.bLoading},
  index:(state)=>{return state.index},
  userdata:(state)=>{return state.user.data},
}