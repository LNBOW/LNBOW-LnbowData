<?php
	$data0 = 
'[{
	"id":"DL10127",
	"img":["http://s.handu.com/images/201804/thumb_img/1524207767345441470.jpg",
			"http://s.handu.com/images/201804/thumb_img/1524207769247681227.jpg"],
	"name":"韩都衣舍2018夏装新款女装韩版宽松学生纯色打底短袖T恤",
	"oldPrice":158.00,
	"newPrice":68.00,
	"sales":1690,
	"stock":309,
	"size":["XS","S","M","L"],
	"color":["黑色","白色","粉色"]
},
{
	"id":"IG8085",
	"img":["http://s.handu.com/images/201804/thumb_img/1069408_thumb_G_1524806912382.jpg",
			"http://s.handu.com/images/201803/thumb_img/1519967546654265739.jpg"],
	"name":"韩都衣舍2018夏装新款女装韩版网纱无袖两件套连衣裙",
	"oldPrice":338.00,
	"newPrice":128.00,
	"sales":1145,
	"stock":1795,
	"size":["XS","S","M","L"],
	"color":["蓝色","米粉色"]
},
{
	"id":"WD7522",
	"img":["http://s.handu.com/images/201804/thumb_img/1524116224551880790.jpg",
			"http://s.handu.com/images/201804/thumb_img/1524116225092440983.jpg"],
	"name":"迪葵纳中年妈妈装2018夏装新款中老年女装上衣T恤",
	"oldPrice":238.00,
	"newPrice":89.00,
	"sales":24,
	"stock":4,
	"size":["L","XL","2XL","3XL","4XL"],
	"color":["浅蓝色"]
},
{
	"id":"NT6915",
	"img":["http://s.handu.com/images/201708/thumb_img/1503951034303878217.jpg",
			"http://s.handu.com/images/201708/thumb_img/1503951035748506173.jpg"],
	"name":"韩都衣舍2018夏装新款女装韩版宽松学生纯色打底短袖T恤",
	"oldPrice":258.00,
	"newPrice":145.00,
	"sales":220,
	"stock":524,
	"size":["XS","S","M","L"],
	"color":["黄色","白色"]
},
{
	"id":"YL6814",
	"img":["http://s.handu.com/images/201709/thumb_img/1063038_thumb_P_1506391719173.jpg",
			"http://s.handu.com/images/201708/thumb_img/1502900496754730602.jpg"],
	"name":"噺米妮哈鲁婴幼童装女宝裙子2017秋装新款女童公主连衣裙",
	"oldPrice":228.00,
	"newPrice":129.00,
	"sales":1,
	"stock":60,
	"size":["80/48","90/52","100/52","110/56"],
	"color":["红色"]
},
{
	"id":"WBZ7453",
	"img":["http://s.handu.com/images/201804/thumb_img/1524707928586220515.jpg",
			"http://s.handu.com/images/201804/thumb_img/1524707929143154838.jpg"],
	"name":"韩都衣舍2018夏装新款女装韩版宽松学生纯色打底短袖T恤",
	"oldPrice":188.00,
	"newPrice":59.00,
	"sales":24,
	"stock":19,
	"size":["S","M","L"],
	"color":["白色","砖红色"]
}]';
	$data1 = 
'[{
	"id":"DL10127",
	"img":["http://s.handu.com/images/201804/thumb_img/1524207767345441470.jpg",
			"http://s.handu.com/images/201804/thumb_img/1524207769247681227.jpg"],
	"name":"韩都衣舍2018夏装新款女装韩版宽松学生纯色打底短袖T恤",
	"oldPrice":158.00,
	"newPrice":68.00,
	"sales":1690,
	"stock":309,
	"size":["XS","S","M","L"],
	"color":["黑色","白色","粉色"]
},
{
	"id":"IG8085",
	"img":["http://s.handu.com/images/201804/thumb_img/1069408_thumb_G_1524806912382.jpg",
			"http://s.handu.com/images/201803/thumb_img/1519967546654265739.jpg"],
	"name":"韩都衣舍2018夏装新款女装韩版网纱无袖两件套连衣裙",
	"oldPrice":338.00,
	"newPrice":128.00,
	"sales":1145,
	"stock":1795,
	"size":["XS","S","M","L"],
	"color":["蓝色","米粉色"]
}]';
	$data2 = 
'[{
	"id":"WD7522",
	"img":["http://s.handu.com/images/201804/thumb_img/1524116224551880790.jpg",
			"http://s.handu.com/images/201804/thumb_img/1524116225092440983.jpg"],
	"name":"迪葵纳中年妈妈装2018夏装新款中老年女装上衣T恤",
	"oldPrice":238.00,
	"newPrice":89.00,
	"sales":24,
	"stock":4,
	"size":["L","XL","2XL","3XL","4XL"],
	"color":["浅蓝色"]
}]';
	$data3 = 
'[{
	"id":"NT6915",
	"img":["http://s.handu.com/images/201708/thumb_img/1503951034303878217.jpg",
			"http://s.handu.com/images/201708/thumb_img/1503951035748506173.jpg"],
	"name":"韩都衣舍2018夏装新款女装韩版宽松学生纯色打底短袖T恤",
	"oldPrice":258.00,
	"newPrice":145.00,
	"sales":220,	
	"stock":524,
	"size":["XS","S","M","L"],
	"color":["黄色","白色"]
}]';
	$data4 = 
'[{
	"id":"YL6814",
	"img":["http://s.handu.com/images/201709/thumb_img/1063038_thumb_P_1506391719173.jpg",
			"http://s.handu.com/images/201708/thumb_img/1502900496754730602.jpg"],
	"name":"噺米妮哈鲁婴幼童装女宝裙子2017秋装新款女童公主连衣裙",
	"oldPrice":228.00,
	"newPrice":129.00,
	"sales":1,
	"stock":60,
	"size":["80/48","90/52","100/52","110/56"],
	"color":["红色"]
}]';
	$data5 = 
'[{
	"id":"WBZ7453",
	"img":["http://s.handu.com/images/201804/thumb_img/1524707928586220515.jpg",
			"http://s.handu.com/images/201804/thumb_img/1524707929143154838.jpg"],
	"name":"韩都衣舍2018夏装新款女装韩版宽松学生纯色打底短袖T恤",
	"oldPrice":188.00,
	"newPrice":59.00,
	"sales":24,
	"stock":19,
	"size":["S","M","L"],
	"color":["白色","砖红色"]
}]';

echo $data5;

$type = $_POST["num"];
if($type == 0){
	echo $data0;	
}if($type == 1){
	echo $data1;	
}
if($type == 2){
	echo $data2;	
}
if($type == 3){
	echo $data3;	
}
if($type == 4){
	echo $data4;	
}
if($type == 5){
	echo $data5;	
}
	

?>